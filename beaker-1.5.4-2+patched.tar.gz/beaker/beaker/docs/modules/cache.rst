:mod:`beaker.cache` -- Cache module 
================================================

.. automodule:: beaker.cache

Module Contents
---------------

.. autofunction:: cache_region
.. autofunction:: region_invalidate
.. autoclass:: Cache
    :members: get, clear
.. autoclass:: CacheManager
    :members: region, region_invalidate, cache, invalidate
