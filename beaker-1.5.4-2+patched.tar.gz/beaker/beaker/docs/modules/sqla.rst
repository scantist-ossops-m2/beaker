:mod:`beaker.ext.sqla` -- SqlAlchemy Container and NameSpace Manager classes 
============================================================================

.. automodule:: beaker.ext.sqla

Module Contents
---------------

.. autofunction:: make_cache_table
.. autoclass:: SqlaContainer
.. autoclass:: SqlaNamespaceManager
   