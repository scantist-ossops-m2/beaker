:mod:`beaker.ext.memcached` -- Memcached Container and NameSpace Manager classes 
================================================================================

.. automodule:: beaker.ext.memcached

Module Contents
---------------

.. autoclass:: MemcachedContainer
.. autoclass:: MemcachedNamespaceManager
   