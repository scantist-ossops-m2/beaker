:mod:`beaker.crypto.pbkdf2` -- PKCS#5 v2.0 Password-Based Key Derivation classes 
================================================================================

.. automodule:: beaker.crypto.pbkdf2

Module Contents
---------------

.. autofunction:: crypt
.. autoclass:: PBKDF2
   :members: close, hexread, read
   