:mod:`beaker.ext.google` -- Google Container and NameSpace Manager classes 
==========================================================================

.. automodule:: beaker.ext.google

Module Contents
---------------

.. autoclass:: GoogleContainer
.. autoclass:: GoogleNamespaceManager
   