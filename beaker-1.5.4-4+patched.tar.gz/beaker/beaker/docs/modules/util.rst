:mod:`beaker.util` -- Beaker Utilities 
========================================================

.. automodule:: beaker.util

Module Contents
---------------
.. autofunction:: encoded_path
.. autofunction:: func_namespace
.. autoclass:: SyncDict
.. autoclass:: ThreadLocal
.. autofunction:: verify_directory
.. autofunction:: b64encode
.. autofunction:: b64decode
.. autofunction:: parse_cache_config_options