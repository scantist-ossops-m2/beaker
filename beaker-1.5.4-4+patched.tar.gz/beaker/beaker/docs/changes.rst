:tocdepth: 2

.. _changes:

Changes in Beaker
*****************

.. include:: ../../CHANGELOG
